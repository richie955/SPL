#include <stdio.h>
#include "../include/common.h"
#include "../include/bar.h"

void bar1() {
    printf("Executing bar1 function from bargodic library\n");
}
