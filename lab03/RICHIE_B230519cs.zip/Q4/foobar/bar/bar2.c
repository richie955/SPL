#include <stdio.h>
#include "../include/common.h"
#include "../include/bar.h"

void bar2() {
    printf("Executing bar2 function from bargodic library\n");
}
