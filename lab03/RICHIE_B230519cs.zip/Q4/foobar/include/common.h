#ifndef COMMON_H
#define COMMON_H

void commonFunction();

#endif // COMMON_H
