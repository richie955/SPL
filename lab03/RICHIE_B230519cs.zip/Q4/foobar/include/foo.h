#ifndef FOO_H
#define FOO_H

void foo1();
void foo2();
void foo3();

#endif 
