#ifndef BAR_H
#define BAR_H

void bar1();
void bar2();

#endif 