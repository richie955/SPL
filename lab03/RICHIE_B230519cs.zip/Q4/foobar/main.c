#include "foo.h"
#include "bar.h"

int main() {
    foo1();
    foo2();
    foo3();
    bar1();
    bar2();

    return 0;
}
