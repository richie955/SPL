#include <stdio.h>
#include "../include/common.h"
#include "../include/foo.h"
void foo3() {
    printf("Executing foo3 function from foomatic library\n");
}
