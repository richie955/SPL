#include <stdio.h>
#include "../include/common.h"
#include "../include/foo.h"

void foo2() {
    printf("Executing foo2 function from foomatic library\n");
}
