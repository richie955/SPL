#include <stdio.h>
#include "../include/common.h"
#include "../include/foo.h"

void foo1() {
    printf("Executing foo1 function from foomatic library\n");
}
