#ifndef MATH_H 
#define MATH_H 
int add(int a, int b); 
int multiply(int a, int b); 
#endif  
