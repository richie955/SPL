#ifndef UTILS_H 
#define UTILS_H 
#include <stdio.h> 
void print_sum(int a, int b); 
void print_product(int a, int b); 
#endif 
