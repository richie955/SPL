#include "math.h" 
// function to add two numbers 
int add(int a, int b) { 
return a + b; 
} 
// function to multiply two numbers 
int multiply(int a, int b) { 
return a * b; 
} 
