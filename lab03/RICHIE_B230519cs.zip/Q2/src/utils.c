#include "utils.h" 
#include "math.h" 
// Function to print the sum of two numbers 
void print_sum(int a, int b) { 
int result = add(a, b); 
printf("Sum: %d\n", result); 
} 
// Function to print the product of two numbers 
void print_product(int a, int b) { 
int result = multiply(a, b); 
printf("Products broo: %d\n", result); 
} 
